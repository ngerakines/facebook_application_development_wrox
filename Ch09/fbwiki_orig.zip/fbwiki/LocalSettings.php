$wgGroupPermissions['*']['edit'] = false;
$wgGroupPermissions['*']['createaccount'] = false;
require_once("$IP/extensions/AuthFacebook/AuthFacebook.php");
