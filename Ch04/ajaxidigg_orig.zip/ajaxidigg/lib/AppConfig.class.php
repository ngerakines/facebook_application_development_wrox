class AppConfig {
  public static $app_name = 'Ajax-i-Digg';
  public static $app_url = 'http://apps.facebook.com/ngajaxidigg/';
  public static $app_callback = 'http://fbapps.socklabs.com/ngajaxidigg/';
  public static $app_id = '7581845291';
  public static $api_key = '09972efed5f03eefefbada8cfd2527af';
  public static $secret  = '5f75adc9751e712751156f6dc38cd71d';
}
