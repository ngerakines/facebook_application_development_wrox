<div id="bodycontent" style="margin: 5px;">
</div>
<script>
<!--
function show_swfobj(parent) {
    var newSwf = document.createElement('fb:swf');
    parent.appendChild(newSwf);
}
show_swfobj(document.getElementById('bodycontent'));
//-->
</script>