<div id="contentroot" style="margin: 5px;">
  <p>Hello <span id="myname">
      <fb:name uid="loggedinuser" useyou="false" />
    </span>.
  </p>
</div>
<script>
<!--
function underline_object(obj) {
  obj.setStyle('border-bottom', '1px dashed red');
}

underline_object(document.getElementById('myname'));
//-->
</script>