<style>
#bodycontent {
  margin: 0px 20px 20px 20px
}
.header {
  font-size: 150%;
  font-weight: bold;
}
li {
  color: blue;
}
</style>
<div id="bodycontent">
  <p class="header">Activities</p>
  <p>I play in the rain.</p>
  <p class="header">Favorite Authors</p>
  <ul>
    <li>Neil Stevenson</li>
    <li>William Gibson</li>
    <li>Leslie M. Orchard</li>
    <li>Mercedes Lackey</li>
  </ul>
</div>